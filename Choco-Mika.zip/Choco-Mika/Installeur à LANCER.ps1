&"$PSScriptroot\install_choco NE PAS LANCER.ps1"
Sleep 120
&"$PSScriptroot\Admin NE PAS LANCER.ps1"
Sleep 120
&"$PSScriptroot\User NE PAS LANCER.ps1"